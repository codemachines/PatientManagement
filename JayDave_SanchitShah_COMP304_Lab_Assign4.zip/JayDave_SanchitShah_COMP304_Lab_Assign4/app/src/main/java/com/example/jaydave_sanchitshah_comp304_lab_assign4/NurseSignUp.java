package com.example.jaydave_sanchitshah_comp304_lab_assign4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NurseSignUp extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nurse_sign_up);
    }
}