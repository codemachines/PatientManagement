package models;

public class Nurse {
}
